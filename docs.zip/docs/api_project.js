define({
  "name": "AUTAR API",
  "version": "1.0.0",
  "description": "HTTP API service",
  "title": "AUTAR API documentation",
  "doc-url": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-05-02T19:28:35.700Z",
    "url": "http://apidocjs.com",
    "version": "0.14.0"
  }
});
